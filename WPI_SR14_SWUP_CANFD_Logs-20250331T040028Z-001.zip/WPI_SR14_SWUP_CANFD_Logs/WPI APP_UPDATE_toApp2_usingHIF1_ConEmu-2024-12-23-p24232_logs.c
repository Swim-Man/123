
D:\05-NXP\01-Work\NXP Car Access Team\NCJ29D6_v14.0_2024.11.07\NCJ29D6 CAS Examples v14.0.0\onhost\src\apps\generic\swup_host_can_uci  
λ ls -l
total 172
-rw-r--r-- 1 Cara.Chiu 197121 54177 10月 28 15:43 nxp_main_ncj29d6_swup_host_can_uci.py
-rw-r--r-- 1 Cara.Chiu 197121 54234 12月 20 13:56 nxp_main_ncj29d6_swup_host_can_uci_WPI.py
-rw-r--r-- 1 Cara.Chiu 197121 54174 12月 23 14:00 nxp_main_ncj29d6_swup_host_can_uci_WPI_ORG.py
drwxr-xr-x 1 Cara.Chiu 197121     0 12月 23 11:41 swup_package_generator/
drwxr-xr-x 1 Cara.Chiu 197121     0 11月 16 19:26 user_guide/

D:\05-NXP\01-Work\NXP Car Access Team\NCJ29D6_v14.0_2024.11.07\NCJ29D6 CAS Examples v14.0.0\onhost\src\apps\generic\swup_host_can_uci  
λ ./py nxp_main_ncj29d6_swup_host_can_uci_WPI_ORG.py 
**************************************************************
Start of NCJ29D6 CAN UCI SWUP HOST demo app!
**************************************************************

Configuration Parameters:
- SWUP_SELECTED_UPDATE      = APP_UPDATE_toApp2_usingHIF1
- SWUP_KEYSTORE_LOCATION    = 0
- CAN_TIMEOUT_MS            = 0 ms
- CAN_IS_FD                 = True
- CAN_USE_EXTENDED_ID       = True
- CAN_MAX_PAYLOAD           = 64 bytes
- CAN_DEVICE_ID             = 0x00000001
- NO_RESET                  = False
- MODE_STEP_BY_STEP         = False
- PRINT_FULL_SWUP_CONTENT   = False
- SILENT_SWUP_STATE         = True

Detected 1 PCAN device(s): [81]
Proceeding with the first device in the list with location = 81

Reading SWUP package:
- Filename          = swup_package_generator/binaries/App2_HifA1_HifB1.pkg
- Size              = 102400 bytes
- Origin ID         = 0x00000002
- Manifest version  = ID: 0x0000: 3.5.0
- Generator version = ID: 0x0000: 3.5.0
- opcode            = UPDATE_BUNDLE (0x7C53)
- Found 4 SWUP components with a total of 24 segments
  Component  ID      Version  Segments  
  0          0xFAFB  2.4.0    1         
  1          0xA001  1.0.0    7         
  2          0xF00A  1.0.0    8         
  3          0xF00B  1.0.0    8         

Resetting device:
Transmitting command CMD_GENERIC_RESET:
[0x20, 0x0E, 0x00, 0x00]
PCAN: OK
Receiving response to command:
No response from PCAN. Probably due to intended reset.
Device reset
Receiving Boot Up Notification:
[0x60, 0x0A, 0x00, 0x10, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0xA0, 0x00, 0x00]
PCAN: OK
Retrieved app version: 1.0.0 (ID: 0xA001)

Activate SWUP from the application:
Transmitting command CMD_APP_ACTIVATE_SWUP:
[0x2E, 0x12, 0x00, 0x00]
PCAN: OK
Receiving response to command:
No response from PCAN. Probably intended reset after successful update.
Receiving Boot Up Notification:
[0x60, 0x0A, 0x00, 0x10, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0A, 0xF0, 0x00, 0x00]
PCAN: OK
Retrieved SWUP CAN HIF Version: 1.0.0 (ID: 0xF00A, Color: SWUPHIF_VERSIONID_A)

Get SWUP version:
Transmitting command CMD_SWUP_GET_VERSION:
[0x2F, 0x02, 0x00, 0x00]
PCAN: OK
Receiving response to command:
[0x4F, 0x02, 0x00, 0x01, 0x00]
PCAN: OK, API: OK
Receiving notification to command:
[0x6F, 0x02, 0x00, 0x20, 0x03, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xDB, 0x1E, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF]
PCAN: OK
SWUP Core Version: 3.1.1 (ID: 0)
SWUP Version:      3.0.0 (ID: 7899)
SWUP State: SWUP_STATE_ACTIVE

Select key-store:
Transmitting command CMD_SWUP_SELECT_KEY_STORE:
[0x2F, 0x1C, 0x00, 0x04, 0x00, 0x00, 0x00, 0x00]
PCAN: OK
Receiving response to command:
[0x4F, 0x1C, 0x00, 0x01, 0x00]
PCAN: OK, API: OK
SWUP State: SWUP_STATE_ACTIVE

Transfer manifest:
Transmitting command CMD_SWUP_TRANSFER_MANIFEST_LONG:
[0x3F, 0x07, 0x00, 0x3C, 0x05, 0xFB, 0x2A, 0x34, 0x29, 0xD7, 0xD8, 0x58, 0x61, 0xA0, 0x92, 0xCB, 0xAB, 0x26, 0xDD, 0x17, 0x17, 0x03, 0xDA, 0x31, 0xED, 0x09, 0xB4, 0xC6, 0xCB, 0x1C, 0xD0, 0x2C, 0x80, 0x8D, 0x83, 0x81, 0x0E, 0x6E, 0x1C, 0xE0, 0x94, 0x6E, 0x01, 0xFE, 0x75, 0x11, 0xC7, 0x9B, 0xB1, 0xA7, 0xE4, 0xBE, 0xF6, 0xA3, 0xE5, 0xAB, 0x26, 0xAF, 0x12, 0x34, 0x4F, 0xA7, 0x8D, 0xF8] ... [0x2F, 0x07, 0x00, 0x10, 0xA7, 0xE4, 0x55, 0x69, 0x43, 0xFA, 0xF3, 0x87, 0x1C, 0x70, 0x31, 0xC1, 0xCC, 0xA9, 0xDE, 0x3A] (69 fragments)
PCAN: OK
Receiving response to command:
[0x4F, 0x07, 0x00, 0x01, 0x00]
PCAN: OK, API: OK
SWUP State: SWUP_STATE_ACTIVE

Start update:
Transmitting command CMD_SWUP_START_UPDATE:
[0x2F, 0x0A, 0x00, 0x00]
PCAN: OK
Receiving response to command:
[0x4F, 0x0A, 0x00, 0x01, 0x00]
PCAN: OK, API: OK
SWUP State: SWUP_STATE_TRANSFER

Verify components:
Found 4 SWUP components
Transmitting command CMD_SWUP_VERIFY_COMPONENT for component 0:
[0x2F, 0x11, 0x00, 0x01, 0x00]
PCAN: OK
Receiving response to command:
[0x4F, 0x11, 0x00, 0x01, 0x00]
PCAN: OK, API: OK
Verification successfull

Transmitting command CMD_SWUP_VERIFY_COMPONENT for component 1:
[0x2F, 0x11, 0x00, 0x01, 0x01]
PCAN: OK
Receiving response to command:
[0x4F, 0x11, 0x00, 0x01, 0x02]
PCAN: OK, API: NOT OK: UCI_STATUS_FAILED
Verification failed

Transmitting command CMD_SWUP_VERIFY_COMPONENT for component 2:
[0x2F, 0x11, 0x00, 0x01, 0x02]
PCAN: OK
Receiving response to command:
[0x4F, 0x11, 0x00, 0x01, 0x00]
PCAN: OK, API: OK
Verification successfull

Transmitting command CMD_SWUP_VERIFY_COMPONENT for component 3:
[0x2F, 0x11, 0x00, 0x01, 0x03]
PCAN: OK
Receiving response to command:
[0x4F, 0x11, 0x00, 0x01, 0x00]
PCAN: OK, API: OK
Verification successfull

Verification attampted for all components
SWUP State: SWUP_STATE_TRANSFER

Check SWUP HIF over-write protection:
Current SWUP CAN HIF ID: 0xF00A
New SWUP CAN HIF IDs:    []
No new (known) SWUP HIFs found to be updated

Transfer components:
Found 4 SWUP components with a total of 24 segments
Found 1 SWUP components with a total of 7 segments that are not verified
  Component  ID      Version  Segments  Status
  0          0xFAFB  2.4.0    1         Verified
  1          0xA001  1.0.0    7         Not verified
  2          0xF00A  1.0.0    8         Verified
  3          0xF00B  1.0.0    8         Verified
Segment 1 of 7 (component 1 of 1) - PCAN: -, API: -:   0%|                                                                                                                                                             | 0/7 [00:00<?, ?it/s]Segment 1 of 7 (in component 1) - Transmitting CMD_SWUP_TRANSFER_COMPONENT - PCAN: OK, API: - :  14%|███████████████▏                                                                                          | 1/7 [00:00<00:00,  7.29it/s]Segment 1 of 7 (in component 1) - Receiving response to command            - PCAN: OK, API: OK:  14%|███████████████▏                                                                                          | 1/7 [00:00<00:01,  5.41it/s]Segment 1 of 7 (in component 1) - Receiving response to command            - PCAN: OK, API: OK:  29%|██████████████████████████████▎                                                                           | 2/7 [00:00<00:00, 10.75it/s]Segment 2 of 7 (in component 1) - Transmitting CMD_SWUP_TRANSFER_COMPONENT - PCAN: OK, API: - :  29%|██████████████████████████████▎                                                                           | 2/7 [00:00<00:00, 10.75it/s]Segment 2 of 7 (in component 1) - Receiving response to command            - PCAN: OK, API: OK:  29%|██████████████████████████████▎                                                                           | 2/7 [00:00<00:00, 10.75it/s]Segment 3 of 7 (in component 1) - Transmitting CMD_SWUP_TRANSFER_COMPONENT - PCAN: OK, API: - :  43%|█████████████████████████████████████████████▍                                                            | 3/7 [00:00<00:00, 10.75it/s]Segment 3 of 7 (in component 1) - Receiving response to command            - PCAN: OK, API: OK:  43%|█████████████████████████████████████████████▍                                                            | 3/7 [00:00<00:00, 10.75it/s]Segment 3 of 7 (in component 1) - Receiving response to command            - PCAN: OK, API: OK:  57%|████████████████████████████████████████████████████████████▌                                             | 4/7 [00:00<00:00,  7.97it/s]Segment 4 of 7 (in component 1) - Transmitting CMD_SWUP_TRANSFER_COMPONENT - PCAN: OK, API: - :  57%|████████████████████████████████████████████████████████████▌                                             | 4/7 [00:00<00:00,  7.97it/s]Segment 4 of 7 (in component 1) - Receiving response to command            - PCAN: OK, API: OK:  57%|████████████████████████████████████████████████████████████▌                                             | 4/7 [00:00<00:00,  7.97it/s]Segment 4 of 7 (in component 1) - Receiving response to command            - PCAN: OK, API: OK:  71%|███████████████████████████████████████████████████████████████████████████▋                              | 5/7 [00:00<00:00,  7.62it/s]Segment 5 of 7 (in component 1) - Transmitting CMD_SWUP_TRANSFER_COMPONENT - PCAN: OK, API: - :  71%|███████████████████████████████████████████████████████████████████████████▋                              | 5/7 [00:00<00:00,  7.62it/s]Segment 5 of 7 (in component 1) - Receiving response to command            - PCAN: OK, API: OK:  71%|███████████████████████████████████████████████████████████████████████████▋                              | 5/7 [00:00<00:00,  7.62it/s]Segment 5 of 7 (in component 1) - Receiving response to command            - PCAN: OK, API: OK:  86%|██████████████████████████████████████████████████████████████████████████████████████████▊               | 6/7 [00:00<00:00,  7.36it/s]Segment 6 of 7 (in component 1) - Transmitting CMD_SWUP_TRANSFER_COMPONENT - PCAN: OK, API: - :  86%|██████████████████████████████████████████████████████████████████████████████████████████▊               | 6/7 [00:00<00:00,  7.36it/s]Segment 6 of 7 (in component 1) - Receiving response to command            - PCAN: OK, API: OK:  86%|██████████████████████████████████████████████████████████████████████████████████████████▊               | 6/7 [00:00<00:00,  7.36it/s]Segment 6 of 7 (in component 1) - Receiving response to command            - PCAN: OK, API: OK: 100%|██████████████████████████████████████████████████████████████████████████████████████████████████████████| 7/7 [00:00<00:00,  7.21it/s]Segment 7 of 7 (in component 1) - Transmitting CMD_SWUP_TRANSFER_COMPONENT - PCAN: OK, API: - : 100%|██████████████████████████████████████████████████████████████████████████████████████████████████████████| 7/7 [00:01<00:00,  7.21it/s]Segment 7 of 7 (in component 1) - Receiving response to command            - PCAN: OK, API: OK: 100%|██████████████████████████████████████████████████████████████████████████████████████████████████████████| 7/7 [00:01<00:00,  7.21it/s]Segment 7 of 7 (in component 1) - Receiving response to command            - PCAN: OK, API: OK: 100%|██████████████████████████████████████████████████████████████████████████████████████████████████████████| 7/7 [00:01<00:00,  6.53it/s]
SWUP package transferred
SWUP State: SWUP_STATE_TRANSFER

Verify all components:
Transmitting command CMD_SWUP_VERIFY_ALL_COMPONENTS:
[0x2F, 0x12, 0x00, 0x00]
PCAN: OK
Receiving response to command:
[0x4F, 0x12, 0x00, 0x01, 0x00]
PCAN: OK, API: OK
All components verified
SWUP State: SWUP_STATE_TRANSFER

Finish update:
Transmitting command CMD_SWUP_FINISH_UPDATE:
[0x2F, 0x1A, 0x00, 0x00]
PCAN: OK
Receiving response to command:
[0x4F, 0x1A, 0x00, 0x01, 0x00]
PCAN: OK, API: OK
SWUP update finished
SWUP State: SWUP_STATE_ACTIVE

Deactivate SWUP:
Transmitting command CMD_SWUP_DEACTIVATE:
[0x2F, 0x1B, 0x00, 0x00]
PCAN: OK
Receiving response to command:
No response from PCAN. Probably intended reset after successful update.
Deactivated SWUP and reset device
Receiving Boot Up Notification:
[0x60, 0x0A, 0x00, 0x10, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0xA0, 0x00, 0x00]
PCAN: OK
Retrieved app version: 1.0.0 (ID: 0xA001)

Execution stats:
Total time:			2.7 s
Transfer time:			1.6 s (57.8 %)
Payload size:			28.67 KB
Payload transfer rate (total):	10.61 KB/s
Payload transfer rate:		18.35 KB/s


**************************************************************
End of NCJ29D6 CAN UCI SWUP HOST demo app!
**************************************************************

